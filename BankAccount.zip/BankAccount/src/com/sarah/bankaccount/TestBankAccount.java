package com.sarah.bankaccount;


class TestBankAccount {
    public static void main(String[] args) {
		BankAccount account1 = new BankAccount();
		
		
		account1.deposit("checking",100.49);
		account1.deposit("savings",30.0);
		account1.balance();

		
		System.out.println(BankAccount.total);

		
		account1.withdraw("checking",0);
		account1.withdraw("savings",70.5);
		account1.balance();

		
		System.out.println(BankAccount.total);

		
	}
}
