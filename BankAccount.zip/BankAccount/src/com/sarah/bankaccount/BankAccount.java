package com.sarah.bankaccount;

public class BankAccount {

	private double checkingBalance;
	private double savingsBalance;
	public static double total = 0;
	public BankAccount( ) {
		
		this.checkingBalance = 0;
		this.savingsBalance = 0;
		
	}
	
	public double getCheckingBalance() {
		return this.checkingBalance;
	}

	public double getSavingsBalance() {
		return this.savingsBalance;
	}
    
	
	
	//withdraw method
	public void withdraw(String account , double amount) {
		boolean done = false;
		
		if(account.equals("checking")) {
		
			if(this.checkingBalance - amount >= 0) {
				done = true;
				this.checkingBalance -= amount;
			}
		}
		else if(account.equals("savings")) {
			// check if enough in account
			if(this.savingsBalance - amount >= 0) {
				done = true;
				this.savingsBalance -= amount;
			}
		}
		
		
		if(done) {
			BankAccount.total -= amount;
		}
        else {
            System.out.println("your account has no enough money, please recharge it");
        }
	}
	
	//deposit method
	public void deposit(String account, double amount) {
		if(account.equals("savings"))
			this.checkingBalance += amount;
		
		else if(account.equals("checking"))
			this.savingsBalance += amount;
		
			BankAccount.total += amount;
	}

	public void balance() {
	
		System.out.printf("Savings: %.2f, Checking: %.2f \n", this.getSavingsBalance(), this.getCheckingBalance());
	}}
